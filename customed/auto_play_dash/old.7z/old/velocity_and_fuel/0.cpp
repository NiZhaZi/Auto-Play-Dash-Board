#include<bits/stdc++.h>
#define pi 3.1415926535897932384626
int main(){
	double side_length = 1;
	while(true){
		scanf("%lf", &side_length);
		double height = side_length / 2 * sqrt(3);
		printf("( %.4lf , %.4lf ) \n", 512 - side_length / 2, 512 + height);
		printf("( %.4lf , %.4lf ) \n", 512 + side_length / 2, 512 + height);
		printf("%lf \n", side_length * 2 * pi * 5 / 6);
	}
	return 0;
}
