//console.log("load gaugesScreen");
angular.module('gaugesScreen', [])

  .controller('GaugesScreenController', function ($scope, $element, $window) {
    "use strict";
    var vm = this;

    var svg;

    var power = { };
    var fuel = { };

    var ready = false;

    $scope.onSVGLoaded = function () {
      svg = $element[0].children[0].children[0];

      power.root = hu('#Velocity', svg);
      power.velocity = hu("#velocity", power.root);
      power.velocity_txt = hu("#velocity_txt", power.root);
      power.fuel = hu("#fuel", power.root);
      power.fuel_txt = hu("#fuel_txt", power.root);

      // fuel.root = hu("#Fuel1", svg);
      // fuel.fuel = hu("#fuel", fuel.root);
      // fuel.fuel_txt = hu("#fuel_txt", fuel.root);

      ready = true;
    }

    const invalidUnit = (unit) => {
      return typeof UiUnits[unit] !== 'function' && !customUnits.includes(unit)
    }

    $window.setup = (data) => {
      if(!ready){
        console.log("calling setup while svg not fully loaded");
        setTimeout(function(){ $window.setup(data) }, 100);
        return;
      }
    }

    $window.updateData = (data) => {
    
      // velocity part
      var rpm = data.electrics.rpmTacho * 1.0;
      var rpmString = (rpm / 8000 * 1963.5).toString() + " 10000"; // full 1963.5

      // var wheelspeed = data.electrics.wheelspeed * 3.6;
      // var velocityString = (wheelspeed / 300 * 1963.5).toString() + " 10000"; // full 1963.5
      // var redline = 150;

      power.velocity.n.style.setProperty("stroke-dasharray", rpmString, "important");

      // var velocity_txt = (wheelspeed * 1.0).toFixed(0);
      // if(velocity_txt == -0){
      //   velocity_txt = 0;
      // }
      // power.velocity_txt.text(velocity_txt);
    }
  })