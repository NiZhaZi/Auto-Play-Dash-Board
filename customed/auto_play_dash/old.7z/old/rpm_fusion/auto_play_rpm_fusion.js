//console.log("load gaugesScreen");
angular.module('gaugesScreen', [])

  .controller('GaugesScreenController', function ($scope, $element, $window) {
    "use strict";
    var vm = this;

    var svg;

    var power = { };
    var fuel = { };

    var ready = false;

    $scope.onSVGLoaded = function () {
      svg = $element[0].children[0].children[0];

      power.root = hu('#Velocity', svg);
      power.velocity = hu("#velocity", power.root);
      power.velocity_txt = hu("#velocity_txt", power.root);
      power.pointer_0 = hu("#pointer_0", power.root);
      power.pointer_1 = hu("#pointer_1", power.root);

      ready = true;
    }

    const invalidUnit = (unit) => {
      return typeof UiUnits[unit] !== 'function' && !customUnits.includes(unit)
    }

    $window.setup = (data) => {
      if(!ready){
        console.log("calling setup while svg not fully loaded");
        setTimeout(function(){ $window.setup(data) }, 100);
        return;
      }
    }

    $window.updateData = (data) => {
    
      // velocity part
      var rpm = data.electrics.rpmTacho * 1.0;
      var rpmAngle = -1 * (rpm * 0.0375 + 30) * (Math.PI / 180);

      var rpmString = (rpm / 8000 * 1963.5).toString() + " 10000";
      power.velocity.n.style.setProperty("stroke-dasharray", rpmString, "important");

      power.pointer_0.attr({ x1: (512 + 362 * Math.sin(rpmAngle)).toString() });
      power.pointer_0.attr({ x2: (512 - 58 * Math.sin(rpmAngle)).toString() });
      power.pointer_0.attr({ y1: (512 + 362 * Math.cos(rpmAngle)).toString() });
      power.pointer_0.attr({ y2: (512 - 58 * Math.cos(rpmAngle)).toString() });

      power.pointer_1.attr({ x1: (512 + 362 * Math.sin(rpmAngle)).toString() });
      power.pointer_1.attr({ x2: (512 - 58 * Math.sin(rpmAngle)).toString() });
      power.pointer_1.attr({ y1: (512 + 362 * Math.cos(rpmAngle)).toString() });
      power.pointer_1.attr({ y2: (512 - 58 * Math.cos(rpmAngle)).toString() });

      var rpm_txt = (rpm / 1000 * 1.0).toFixed(0);
      if(rpm_txt == -0){
        rpm_txt = 0;
      }
      power.velocity_txt.text(rpm_txt);
    }
  })